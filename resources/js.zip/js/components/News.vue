<template>
    <h3>sa</h3>
</template>

<script>
    export default {
        name: "News"
    }
</script>

<style scoped>

</style>