<template>
    
</template>

<script>
    export default {
        name: "ViewArticle"
    }
</script>

<style scoped>

</style>