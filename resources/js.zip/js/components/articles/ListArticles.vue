<template id="article-list">
    <b-row>
        <router-link class="btn btn-warning" v-bind:to="{path: 'articles/add-article'}">Add New Post</router-link>
    </b-row>
</template>

<script>
    export default {
        name: "ListArticles",
        created: function() {
        },
    }

</script>
<style scoped>

</style>