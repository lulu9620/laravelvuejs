<template id="add-article">
    <div>
        <h3>Add new Article</h3>
        <form v-on:submit.prevent ="createArticle">
            <b-form-group
                    id="input-group-1"
                    label="Email address:"
                    label-for="input-1"
                    description="We'll never share your email with anyone else.">
                <b-form-input
                        id="input-1"
                        v-model="form.email"
                        type="email"
                        required
                        placeholder="Enter email"
                ></b-form-input>
            </b-form-group>
        </form>
    </div>

</template>

<script>
    export default {
        name: "AddArticle"
    }
</script>

<style scoped>

</style>