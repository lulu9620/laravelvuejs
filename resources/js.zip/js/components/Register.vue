<template>
    <h3>Register</h3>
</template>

<script>
    export default {
        name: "Register"
    }
</script>

<style scoped>

</style>